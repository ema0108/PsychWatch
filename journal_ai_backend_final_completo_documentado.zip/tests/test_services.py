
# test_services.py
# Pruebas de los módulos internos del backend

from services.analysis_service import analizar_texto
from services.diagnostics import resumen_clinico
from services.sentiment import analyze_sentiment
from services.emotions import detect_emotions

def test_sentiment():
    res = analyze_sentiment("Estoy muy feliz hoy.")
    assert "polarity" in res or "label" in res

def test_emotions():
    res = detect_emotions("Tengo miedo y estoy nervioso.")
    assert "emotions" in res

def test_diagnostics():
    texto = "No tengo motivación desde hace más de dos semanas. Me siento vacío."
    resultado = resumen_clinico(texto)
    assert "posibles_diagnosticos" in resultado

def test_analisis_completo():
    resultado = analizar_texto("Estoy estresado desde hace meses.")
    assert "emociones" in resultado
    assert "sentimiento" in resultado
    assert "diagnostico" in resultado
