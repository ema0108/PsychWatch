
# test_api.py
# Pruebas básicas de integración para los endpoints Flask

import pytest
from main import create_app

@pytest.fixture
def client():
    app = create_app()
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client

def test_home(client):
    res = client.get("/")
    assert res.status_code == 200
    assert res.get_json()["status"] == "ok"

def test_login(client):
    res = client.post("/login", json={"usuario": "testuser"})
    assert res.status_code == 200
    assert "token" in res.get_json()

def test_analizar(client):
    texto = "Me siento triste y sin motivación desde hace semanas."
    res = client.post("/analizar", json={"texto": texto})
    assert res.status_code == 200
    data = res.get_json()
    assert "sentimiento" in data
    assert "emociones" in data
    assert "diagnostico" in data
