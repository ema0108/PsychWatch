"""
Análisis de sentimiento con TextBlob y Transformers.
"""


# Importación de librerías
from textblob import TextBlob
# Importación de librerías
from transformers import pipeline

# Cargar el pipeline de análisis de sentimiento (transformers)
# NOTA: Este modelo es multilingüe y debe pre-cargarse en entorno online
try:
    sentiment_pipeline = pipeline("sentiment-analysis", model="nlptown/bert-base-multilingual-uncased-sentiment")
except Exception:
    sentiment_pipeline = None  # Fallback offline

# Función: analyze_sentiment_textblob
def analyze_sentiment_textblob(text):
    blob = TextBlob(text)
    return {
        "polarity": blob.sentiment.polarity,
        "subjectivity": blob.sentiment.subjectivity,
        "method": "textblob"
    }

# Función: analyze_sentiment_transformers
def analyze_sentiment_transformers(text):
    if not sentiment_pipeline:
        return {"error": "Transformers model not available in offline mode."}
    
    result = sentiment_pipeline(text[:512])[0]  # Limit to model input length
    return {
        "label": result["label"],
        "score": result["score"],
        "method": "transformers"
    }

# Función: analyze_sentiment
def analyze_sentiment(text, method="textblob"):
    if method == "transformers":
        return analyze_sentiment_transformers(text)
    else:
        return analyze_sentiment_textblob(text)
