"""
Servicio principal de análisis emocional y diagnóstico preliminar.
Ahora también incluye un clasificador DSM entrenado con DAIC-WOZ si está disponible.
"""

from data.db import guardar_entrada, obtener_historial
from services.sentiment import analyze_sentiment
from services.emotions import detect_emotions
from services.diagnostics import resumen_clinico

# Nuevo: integración DSM si está entrenado
import os
try:
    from transformers import AutoTokenizer, AutoModelForSequenceClassification, pipeline
    if os.path.exists("./modelo_dsm"):
        dsm_tokenizer = AutoTokenizer.from_pretrained("./modelo_dsm")
        dsm_model = AutoModelForSequenceClassification.from_pretrained("./modelo_dsm")
        dsm_pipeline = pipeline("text-classification", model=dsm_model, tokenizer=dsm_tokenizer)
    else:
        dsm_pipeline = None
except:
    dsm_pipeline = None

def clasificacion_dsm(texto):
    if dsm_pipeline:
        try:
            res = dsm_pipeline(texto[:512])[0]
            return {
                "clasificacion_dsm": "Depresión" if res["label"] == "LABEL_1" else "No depresivo",
                "confianza": round(res["score"], 3)
            }
        except:
            return {"error": "Error al ejecutar el modelo DSM"}
    return {"clasificacion_dsm": "Modelo DSM no disponible"}

def analizar_texto(texto):
    sentimiento = analyze_sentiment(texto)
    emociones = detect_emotions(texto)
    diagnostico = resumen_clinico(texto)
    dsm = clasificacion_dsm(texto)

    return {
        "sentimiento": sentimiento,
        "emociones": emociones,
        "diagnostico": diagnostico,
        "dsm_clasificacion": dsm
    }

def guardar_entrada_servicio(usuario, texto):
    resultado = analizar_texto(texto)
    guardar_entrada(usuario, texto, resultado["sentimiento"], resultado["emociones"], resultado["diagnostico"])
    return {
        "mensaje": "Entrada guardada correctamente.",
        **resultado
    }

def obtener_historial_servicio(usuario):
    return obtener_historial(usuario)
