
"""
Detección de emociones usando modelo fine-tuned o reglas básicas como fallback.
"""

from transformers import pipeline
import re
import os

# Intentar cargar modelo entrenado personalizado
MODEL_DIR = "./modelo_emocional"
emotion_pipeline = None

if os.path.exists(MODEL_DIR):
    try:
        emotion_pipeline = pipeline("text-classification", model=MODEL_DIR, tokenizer=MODEL_DIR, top_k=1)
    except:
        emotion_pipeline = None

# Reglas básicas (solo si el modelo no está disponible)
emotion_keywords = {
    "alegría": ["feliz", "contento", "alegre", "entusiasmado", "emocionado"],
    "tristeza": ["triste", "deprimido", "melancólico", "llorar", "sollozar"],
    "miedo": ["asustado", "miedo", "nervioso", "ansioso", "temor"],
    "ira": ["enojado", "molesto", "furioso", "rabia", "enojo"],
    "ansiedad": ["ansioso", "preocupado", "inquieto", "estresado"],
    "amor": ["amor", "querer", "amar", "cariño", "afecto"]
}

def emotion_rules_based(text):
    text = text.lower()
    results = {}
    for emotion, keywords in emotion_keywords.items():
        matches = sum(1 for word in keywords if re.search(rf"\b{word}\b", text))
        if matches:
            results[emotion] = matches
    return sorted(results.items(), key=lambda x: x[1], reverse=True)

def detect_emotions(text):
    if emotion_pipeline:
        try:
            result = emotion_pipeline(text[:512])
            return {"emotions": result, "method": "fine-tuned"}
        except:
            pass
    # Fallback si no hay modelo
    rule_based = emotion_rules_based(text)
    return {"emotions": rule_based, "method": "rules"}
