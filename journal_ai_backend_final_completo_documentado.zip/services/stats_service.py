"""
Servicio que genera estadísticas longitudinales por usuario.
"""


# Importación de librerías
from data.db import obtener_historial
# Importación de librerías
from collections import defaultdict
# Importación de librerías
import datetime

# Función: analizar_estadisticas
def analizar_estadisticas(usuario):
    historial = obtener_historial(usuario)
    if not historial:
        return {"mensaje": "No hay entradas registradas."}

    emociones_acumuladas = defaultdict(int)
    sentimiento_total = 0
    sentimiento_count = 0
    fechas = []

    for entrada in historial:
        emociones = entrada.get("emociones", {}).get("emotions", [])
        if isinstance(emociones, list):
            for emo in emociones:
                if isinstance(emo, dict):
                    emociones_acumuladas[emo.get("label", "")] += 1
                elif isinstance(emo, tuple):  # reglas
                    emociones_acumuladas[emo[0]] += emo[1]
        sentimiento = entrada.get("sentimiento", {}).get("polarity")
        if sentimiento is not None:
            sentimiento_total += sentimiento
            sentimiento_count += 1
        fechas.append(entrada.get("fecha"))

    estadisticas = {
        "total_entradas": len(historial),
        "emociones_frecuentes": dict(sorted(emociones_acumuladas.items(), key=lambda x: x[1], reverse=True)),
        "promedio_sentimiento": round(sentimiento_total / sentimiento_count, 3) if sentimiento_count else None,
        "rango_fechas": {
            "inicio": min(fechas) if fechas else None,
            "fin": max(fechas) if fechas else None
        }
    }

    return estadisticas
