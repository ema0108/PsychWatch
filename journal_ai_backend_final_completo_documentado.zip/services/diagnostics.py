"""
Diagnóstico preliminar basado en síntomas del DSM-5.
"""


# Importación de librerías
import re
# Importación de librerías
from datetime import datetime

# Palabras clave asociadas a posibles diagnósticos (simplificadas)
DSM_RULES = {
    "depresión": {
        "keywords": ["tristeza", "vacío", "desesperanza", "inútil", "culpa", "fatiga", "insomnio", "sin energía", "sin motivación"],
        "duration_keywords": ["2 semanas", "quince días", "más de dos semanas"]
    },
    "ansiedad": {
        "keywords": ["preocupación", "ansioso", "inquieto", "tensión", "miedo constante", "temor", "nervioso"],
        "duration_keywords": ["6 meses", "seis meses", "varios meses"]
    },
    "burnout": {
        "keywords": ["agotado", "cansado", "sin motivación", "estresado", "saturado", "sobrepasado"],
        "duration_keywords": ["meses", "mucho tiempo"]
    }
}

# Función: check_diagnostic
def check_diagnostic(text, rules=DSM_RULES):
    text_lower = text.lower()
    results = []

    for condition, data in rules.items():
        keyword_hits = [kw for kw in data["keywords"] if re.search(rf"\b{kw}\b", text_lower)]
        duration_hits = [d for d in data["duration_keywords"] if d in text_lower]
        
        if keyword_hits:
            score = len(keyword_hits)
            results.append({
                "condición": condition,
                "síntomas_detectados": keyword_hits,
                "duración_mencionada": duration_hits,
                "score": score + len(duration_hits)
            })

    # Ordenar por score descendente
    results = sorted(results, key=lambda x: x["score"], reverse=True)
    return results

# Función: resumen_clinico
def resumen_clinico(text):
    posibles_diagnosticos = check_diagnostic(text)
    resumen = {
        "resumen": "Diagnóstico preliminar basado en análisis de texto.",
        "posibles_diagnosticos": posibles_diagnosticos,
        "timestamp": datetime.now().isoformat()
    }
    return resumen
